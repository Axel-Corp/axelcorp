import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email(subject, body, to_email):
    try:
        EMAIL_ADDRESS = "Ton_email@example.com"
        EMAIL_PASSWORD = "ton_mot_de_passe"
        
        # Création du message
        msg = MIMEMultipart()
        msg['From'] = EMAIL_ADDRESS
        msg['To'] = to_email
        msg['Subject'] = subject
        
        # Format HTML pour le corps du message
        html_body = f"""
        <html>
        <head>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    color: #333;
                    background-color: #f4f4f4;
                    padding: 20px;
                }}
                h1 {{
                    color: #4CAF50;
                }}
                p {{
                    font-size: 16px;
                    line-height: 1.6;
                }}
                .footer {{
                    font-size: 12px;
                    color: #777;
                }}
                .button {{
                    background-color: #4CAF50;
                    color: white;
                    padding: 10px 20px;
                    text-decoration: none;
                    border-radius: 5px;
                }}
                
            </style>
        </head>
        <body>
            <h1>{subject}</h1>
            <p>{body}</p>
            <p class="footer">Cordialement, <br/> Votre entreprise</p>
        </body>
        </html>
        """
        
        # Attacher le message HTML au courriel
        msg.attach(MIMEText(html_body, 'html'))
        
        # Connexion et envoi de l'email
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()  # Sécuriser la connexion
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)  # Se connecter au serveur
            server.sendmail(EMAIL_ADDRESS, to_email, msg.as_string())  # Envoyer l'email
            
        print("Email envoyé avec succès !")
    
    except Exception as e:
        print(f"Erreur lors de l'envoi de l'email: {e}")
