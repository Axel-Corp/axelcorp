from tkinter import *
from tkinter import ttk, messagebox
import sqlite3
import datetime
from tkcalendar import Calendar
from email_service import send_email  # Si la fonction send_email est dans ce module

# Création ou connexion à la base de données
conn = sqlite3.connect("absensipro.db")
cursor = conn.cursor()

# Création des tables avec un champ pour l'email
cursor.execute("""
CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    position TEXT,
    leave_balance INTEGER DEFAULT 20,
    email TEXT NOT NULL
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS leave_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER,
    start_date TEXT,
    end_date TEXT,
    status TEXT DEFAULT 'Pending',
    FOREIGN KEY (employee_id) REFERENCES employees (id)
)
""")
conn.commit()

# Fonctionnalités
def add_employee():
    def save_employee():
        name = entry_name.get()
        position = entry_position.get()
        balance = int(entry_balance.get())
        email = entry_email.get()
        if name and email:
            cursor.execute(
                "INSERT INTO employees (name, position, leave_balance, email) VALUES (?, ?, ?, ?)",
                (name, position, balance, email)
            )
            conn.commit()
            messagebox.showinfo("Succès", "Employé ajouté avec succès !")
            window_add.destroy()
            load_employees()
        else:
            messagebox.showerror("Erreur", "Le nom de l'employé et l'email sont obligatoires.")

    window_add = Toplevel(root)
    window_add.title("Ajouter un employé")
    Label(window_add, text="Nom :").grid(row=0, column=0, padx=10, pady=10)
    entry_name = Entry(window_add)
    entry_name.grid(row=0, column=1, padx=10, pady=10)
    Label(window_add, text="Poste :").grid(row=1, column=0, padx=10, pady=10)
    entry_position = Entry(window_add)
    entry_position.grid(row=1, column=1, padx=10, pady=10)
    Label(window_add, text="Solde de congés :").grid(row=2, column=0, padx=10, pady=10)
    entry_balance = Entry(window_add)
    entry_balance.grid(row=2, column=1, padx=10, pady=10)
    entry_balance.insert(0, "20")
    Label(window_add, text="Email :").grid(row=3, column=0, padx=10, pady=10)
    entry_email = Entry(window_add)
    entry_email.grid(row=3, column=1, padx=10, pady=10)
    Button(window_add, text="Sauvegarder", command=save_employee).grid(row=4, columnspan=2, pady=10)

def load_employees():
    for row in tree_employees.get_children():
        tree_employees.delete(row)
    cursor.execute("SELECT * FROM employees")
    for employee in cursor.fetchall():
        tree_employees.insert("", "end", values=employee)

def view_employee_calendar(event=None):  # Permet de traiter l'événement ou non
    selected_item = tree_employees.selection()
    if not selected_item:
        return
    employee_id = tree_employees.item(selected_item)["values"][0]
    employee_name = tree_employees.item(selected_item)["values"][1]

    window_calendar = Toplevel(root)
    window_calendar.title(f"Calendrier de congés de {employee_name}")
    
    # Sélectionner le congé de l'employé
    cursor.execute("SELECT * FROM leave_requests WHERE employee_id = ?", (employee_id,))
    leave_requests = cursor.fetchall()

    # Affichage des congés dans une Listbox
    listbox = Listbox(window_calendar, height=6)
    for leave in leave_requests:
        listbox.insert(END, f"Du {leave[2]} au {leave[3]} - Statut : {leave[4]}")
    listbox.pack(padx=10, pady=10)

    # Ajouter un calendrier pour sélectionner une nouvelle période de congé
    calendar_start = Calendar(window_calendar, date_pattern="yyyy-mm-dd")
    calendar_start.pack(padx=10, pady=10)
    calendar_end = Calendar(window_calendar, date_pattern="yyyy-mm-dd")
    calendar_end.pack(padx=10, pady=10)

    def submit_request():
        start_date = calendar_start.get_date()
        end_date = calendar_end.get_date()

        # Calculer la durée des congés
        start = start_date.split('-')
        end = end_date.split('-')
        start_date_obj = datetime.date(int(start[0]), int(start[1]), int(start[2]))
        end_date_obj = datetime.date(int(end[0]), int(end[1]), int(end[2]))
        leave_duration = (end_date_obj - start_date_obj).days + 1

        cursor.execute("SELECT leave_balance FROM employees WHERE id = ?", (employee_id,))
        leave_balance = cursor.fetchone()[0]

        if leave_duration <= leave_balance:
            cursor.execute(
                "INSERT INTO leave_requests (employee_id, start_date, end_date) VALUES (?, ?, ?)",
                (employee_id, start_date, end_date)
            )
            cursor.execute("UPDATE employees SET leave_balance = leave_balance - ? WHERE id = ?",
                           (leave_duration, employee_id))
            conn.commit()

            # Envoyer l'email de notification
            cursor.execute("SELECT email FROM employees WHERE id = ?", (employee_id,))
            email = cursor.fetchone()[0]
            subject = f"Demande de congé"
            body = f"Vous, {employee_name} a demandé un congé du {start_date} au {end_date}."
            send_email(subject, body, email)  # Envoi d'un email à l'employé

            messagebox.showinfo("Succès", "Demande de congé soumise et solde mis à jour !")
            window_calendar.destroy()
            load_employees()
        else:
            messagebox.showerror("Erreur", "Solde de congés insuffisant.")

    Button(window_calendar, text="Soumettre la demande", command=submit_request).pack(pady=10)

# Interface principale
root = Tk()
root.title("AbsensiPro - Gestion des congés")

frame = Frame(root)
frame.pack(padx=20, pady=20)

tree_employees = ttk.Treeview(frame, columns=("ID", "Nom", "Poste", "Solde", "Email"), show="headings", height=10)
tree_employees.heading("ID", text="ID")
tree_employees.heading("Nom", text="Nom")
tree_employees.heading("Poste", text="Poste")
tree_employees.heading("Solde", text="Solde")
tree_employees.heading("Email", text="Email")
tree_employees.pack()

tree_employees.bind("<Double-1>", view_employee_calendar)  # Double-clic pour afficher le calendrier

# Ajouter un employé et demander un congé
Button(root, text="Ajouter un employé", command=add_employee).pack(side=LEFT, padx=10, pady=10)
Button(root, text="Demander un congé", command=view_employee_calendar).pack(side=LEFT, padx=10, pady=10)

load_employees()
root.mainloop()
